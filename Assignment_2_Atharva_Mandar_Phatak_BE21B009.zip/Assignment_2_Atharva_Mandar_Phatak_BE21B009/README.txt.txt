'main.py' files contains the code of FN model 
'Figures' folder contains the output graphs 

'Supporting_file.py' contains the code for finding I1 and I2 values  