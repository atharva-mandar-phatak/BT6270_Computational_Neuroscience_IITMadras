#########################################################################################
The folder provides the code and report for the Hopf Oscillator
#########################################################################################
'Report_BE21B009_Atharva_Mandar_Phatak.pdf' is the pdf copy of the report
#########################################################################################
'complex_coupling.py' contains python code for complex coupling of two Hopf Oscillators
#########################################################################################
'power_coupling.py' contains python code for power coupling of rwo Hopf Oscillators
#########################################################################################
'Figures' folder contains the figures(plots) in the report
#########################################################################################