The folder contains the following(apart from README.txt file):

A]Folder:
1)'Figures'; Containes the figures in the attached report 

B]Files 
1)HH_model_1 :This is the given code ,python file  

2)HH_model_2 :This code plots the Frequency vs Iext graph ,python file  

3)BT6270_Assignment_1_Question :This contains the assignment questions, word doc

4)Report :This is the detailed report/submission , pdf